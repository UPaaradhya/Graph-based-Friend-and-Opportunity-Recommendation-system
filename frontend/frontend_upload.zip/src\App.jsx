import React, { useState, useEffect } from 'react';
import api from './api';

export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [health, setHealth] = useState(null);
  const [catalogs, setCatalogs] = useState({ skills: [], interests: [], courses: [] });

  // Auth states
  const [loginId, setLoginId] = useState('1');
  const [loginPassword, setLoginPassword] = useState('ehn#$QJ2ay');
  const [regName, setRegName] = useState('');
  const [regCourse, setRegCourse] = useState('');
  const [regSkills, setRegSkills] = useState([]);
  const [regInterests, setRegInterests] = useState([]);
  const [regPassword, setRegPassword] = useState('');
  const [authMode, setAuthMode] = useState('login'); // 'login' | 'register'

  // Data states
  const [friendRecs, setFriendRecs] = useState([]);
  const [oppRecs, setOppRecs] = useState([]);
  const [allOpportunities, setAllOpportunities] = useState([]);
  const [opportunityTree, setOpportunityTree] = useState(null);
  const [dfsTraversal, setDfsTraversal] = useState([]);
  const [allUsersList, setAllUsersList] = useState([]);

  // Mutual & Common Friends state
  const [compareUser1, setCompareUser1] = useState('');
  const [compareUser2, setCompareUser2] = useState('');
  const [mutualResult, setMutualResult] = useState(null);
  const [commonAttrs, setCommonAttrs] = useState(null);

  // New opportunity state
  const [newOppName, setNewOppName] = useState('');
  const [newOppType, setNewOppType] = useState('Project');
  const [newOppSkill, setNewOppSkill] = useState('');
  const [newOppInterest, setNewOppInterest] = useState('');

  // Alerts & loading
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Initial load
  useEffect(() => {
    loadHealth();
    loadCatalogs();
  }, []);

  // When currentUser changes, load recommendations and traversal
  useEffect(() => {
    if (currentUser) {
      loadUserData(currentUser.id);
    }
  }, [currentUser?.id]);

  const showNotification = (msg, isError = false) => {
    if (isError) {
      setErrorMsg(msg);
      setTimeout(() => setErrorMsg(''), 5000);
    } else {
      setSuccessMsg(msg);
      setTimeout(() => setSuccessMsg(''), 4000);
    }
  };

  const loadHealth = async () => {
    try {
      const h = await api.getHealth();
      setHealth(h);
    } catch (err) {
      console.warn('Could not fetch health:', err.message);
    }
  };

  const loadCatalogs = async () => {
    try {
      const c = await api.getCatalogs();
      setCatalogs(c);
      if (c.courses?.length > 0) setRegCourse(c.courses[0]);
      if (c.skills?.length > 0) setNewOppSkill(c.skills[0]);
      if (c.interests?.length > 0) setNewOppInterest(c.interests[0]);
    } catch (err) {
      console.warn('Could not fetch catalogs:', err.message);
    }
  };

  const loadUserData = async (userId) => {
    setLoading(true);
    try {
      const [u, fRecs, oRecs, opps, tree, dfs, allU] = await Promise.all([
        api.getUser(userId),
        api.getFriendRecommendations(userId, 10).catch(() => []),
        api.getOpportunityRecommendations(userId, 10).catch(() => []),
        api.getOpportunities().catch(() => []),
        api.getOpportunities(true).catch(() => null),
        api.getDfsTraversal(userId).catch(() => []),
        api.getAllUsers().catch(() => []),
      ]);

      setCurrentUser(u);
      setFriendRecs(fRecs);
      setOppRecs(oRecs);
      setAllOpportunities(opps);
      setOpportunityTree(tree);
      setDfsTraversal(dfs);
      setAllUsersList(allU);
    } catch (err) {
      showNotification(err.message, true);
    } finally {
      setLoading(false);
    }
  };

  // Handle Login
  const handleLogin = async (e) => {
    if (e) e.preventDefault();
    setErrorMsg('');
    try {
      const res = await api.login(loginId, loginPassword);
      setCurrentUser(res.user);
      showNotification(`Welcome back, ${res.user.name}!`);
      loadHealth();
    } catch (err) {
      showNotification(err.message, true);
    }
  };

  // Handle Quick Demo Login
  const handleQuickLogin = (id, pass) => {
    setLoginId(String(id));
    setLoginPassword(pass);
    api.login(id, pass)
      .then((res) => {
        setCurrentUser(res.user);
        showNotification(`Logged in as demo user ${res.user.name}`);
        loadHealth();
      })
      .catch((err) => showNotification(err.message, true));
  };

  // Handle Registration
  const handleRegister = async (e) => {
    e.preventDefault();
    setErrorMsg('');
    if (!regName.trim() || !regPassword.trim()) {
      showNotification('Please fill in your name and password.', true);
      return;
    }
    try {
      const res = await api.register({
        name: regName,
        course: regCourse,
        skills: regSkills,
        interests: regInterests,
        password: regPassword,
      });
      setCurrentUser(res.user);
      showNotification(`Account created! Your assigned User ID is ${res.user.id}.`);
      loadHealth();
    } catch (err) {
      showNotification(err.message, true);
    }
  };

  // Handle Add Friend
  const handleAddFriend = async (targetUserId) => {
    try {
      await api.addFriendship(currentUser.id, targetUserId);
      showNotification('Friend added successfully!');
      loadUserData(currentUser.id);
      loadHealth();
    } catch (err) {
      showNotification(err.message, true);
    }
  };

  // Handle Take Opportunity
  const handleTakeOpportunity = async (oppId) => {
    try {
      await api.takeOpportunity(currentUser.id, oppId);
      showNotification('Opportunity added to your completed profile!');
      loadUserData(currentUser.id);
      loadHealth();
    } catch (err) {
      showNotification(err.message, true);
    }
  };

  // Handle Mutual and Common Friends lookup
  const handleCompareUsers = async (e) => {
    e.preventDefault();
    if (!compareUser1 || !compareUser2) return;
    try {
      const [mutual, common] = await Promise.all([
        api.getMutualFriends(compareUser1, compareUser2),
        api.getCommonAttributes(compareUser1, compareUser2),
      ]);
      setMutualResult(mutual);
      setCommonAttrs(common);
    } catch (err) {
      showNotification(err.message, true);
    }
  };

  // Handle Create New Opportunity
  const handleCreateOpportunity = async (e) => {
    e.preventDefault();
    if (!newOppName.trim()) return;
    try {
      await api.createOpportunity({
        name: newOppName,
        type: newOppType,
        skill: newOppSkill,
        interest: newOppInterest,
      });
      showNotification(`Opportunity "${newOppName}" created successfully!`);
      setNewOppName('');
      loadUserData(currentUser.id);
      loadHealth();
    } catch (err) {
      showNotification(err.message, true);
    }
  };

  // Toggle skill in register form
  const toggleSkill = (skill) => {
    if (regSkills.includes(skill)) {
      setRegSkills(regSkills.filter((s) => s !== skill));
    } else {
      if (regSkills.length < 5) setRegSkills([...regSkills, skill]);
      else showNotification('Maximum 5 skills allowed.', true);
    }
  };

  // Toggle interest in register form
  const toggleInterest = (interest) => {
    if (regInterests.includes(interest)) {
      setRegInterests(regInterests.filter((i) => i !== interest));
    } else {
      if (regInterests.length < 4) setRegInterests([...regInterests, interest]);
      else showNotification('Maximum 4 interests allowed.', true);
    }
  };

  return (
    <div>
      {/* Navbar */}
      <nav className="navbar">
        <div className="logo-area">
          <div className="logo-icon">C</div>
          <div className="logo-text">
            <h1>Connectly</h1>
            <span>Friend & Opportunity Recommendation System</span>
          </div>
        </div>

        <div className="nav-status">
          {health && (
            <div className="status-badge" title={health.mode}>
              <span className={`dot ${health.neo4jConnected ? 'online' : 'offline'}`} />
              <span>{health.mode}</span>
            </div>
          )}

          {currentUser && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <span style={{ fontSize: '0.9rem', color: '#93c5fd' }}>
                👤 {currentUser.name} (ID: {currentUser.id})
              </span>
              <button
                className="btn btn-outline btn-sm"
                onClick={() => {
                  setCurrentUser(null);
                  showNotification('Logged out successfully.');
                }}
              >
                Logout
              </button>
            </div>
          )}
        </div>
      </nav>

      {/* Main Container */}
      <div className="container">
        {/* Global Notifications */}
        {errorMsg && <div className="alert alert-error">⚠️ {errorMsg}</div>}
        {successMsg && <div className="alert alert-success">✅ {successMsg}</div>}

        {/* Not Logged In View */}
        {!currentUser ? (
          <div style={{ maxWidth: '650px', margin: '2rem auto' }}>
            {/* Quick Demo Login Bar */}
            <div className="card" style={{ marginBottom: '1.5rem', background: '#0b1633' }}>
              <h3 style={{ fontSize: '1rem', color: '#93c5fd', marginBottom: '0.5rem' }}>
                ⚡ Quick Demo Login (Preloaded 100 Users)
              </h3>
              <p style={{ fontSize: '0.85rem', color: '#94a3b8', marginBottom: '0.75rem' }}>
                Select a sample student profile to instantly test the recommendation system:
              </p>
              <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                <button
                  className="btn btn-outline btn-sm"
                  onClick={() => handleQuickLogin(1, 'ehn#$QJ2ay')}
                >
                  Kavya Rana (ID: 1 - CSE)
                </button>
                <button
                  className="btn btn-outline btn-sm"
                  onClick={() => handleQuickLogin(2, 'oKY!HDME72')}
                >
                  Bhavya Bhandari (ID: 2 - AI/ML)
                </button>
                <button
                  className="btn btn-outline btn-sm"
                  onClick={() => handleQuickLogin(38, 'R7z%L!mrjU')}
                >
                  Chirag Verma (ID: 38 - CS)
                </button>
              </div>
            </div>

            {/* Auth Card */}
            <div className="card">
              <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.25rem', borderBottom: '1px solid var(--border)', paddingBottom: '0.5rem' }}>
                <button
                  className={`tab-btn ${authMode === 'login' ? 'active' : ''}`}
                  onClick={() => setAuthMode('login')}
                >
                  Sign In
                </button>
                <button
                  className={`tab-btn ${authMode === 'register' ? 'active' : ''}`}
                  onClick={() => setAuthMode('register')}
                >
                  Create Account
                </button>
              </div>

              {authMode === 'login' ? (
                <form onSubmit={handleLogin}>
                  <div className="form-group">
                    <label className="form-label">User ID</label>
                    <input
                      type="number"
                      className="form-control"
                      value={loginId}
                      onChange={(e) => setLoginId(e.target.value)}
                      placeholder="e.g. 1"
                      required
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Password</label>
                    <input
                      type="password"
                      className="form-control"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="Password"
                      required
                    />
                  </div>

                  <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '0.5rem' }}>
                    Sign In
                  </button>
                </form>
              ) : (
                <form onSubmit={handleRegister}>
                  <div className="form-group">
                    <label className="form-label">Full Name</label>
                    <input
                      type="text"
                      className="form-control"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      placeholder="Your Full Name"
                      required
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Course / Degree</label>
                    <select
                      className="form-control"
                      value={regCourse}
                      onChange={(e) => setRegCourse(e.target.value)}
                    >
                      {catalogs.courses.map((c) => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Select Skills (Max 5)</label>
                    <div className="badge-group" style={{ maxHeight: '120px', overflowY: 'auto' }}>
                      {catalogs.skills.map((s) => (
                        <span
                          key={s}
                          onClick={() => toggleSkill(s)}
                          className={`tag tag-skill`}
                          style={{
                            cursor: 'pointer',
                            background: regSkills.includes(s) ? '#2563eb' : undefined,
                            color: regSkills.includes(s) ? '#fff' : undefined,
                          }}
                        >
                          {s} {regSkills.includes(s) ? '✓' : '+'}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Select Interests (Max 4)</label>
                    <div className="badge-group" style={{ maxHeight: '100px', overflowY: 'auto' }}>
                      {catalogs.interests.map((i) => (
                        <span
                          key={i}
                          onClick={() => toggleInterest(i)}
                          className={`tag tag-interest`}
                          style={{
                            cursor: 'pointer',
                            background: regInterests.includes(i) ? '#7c3aed' : undefined,
                            color: regInterests.includes(i) ? '#fff' : undefined,
                          }}
                        >
                          {i} {regInterests.includes(i) ? '✓' : '+'}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Create Password</label>
                    <input
                      type="password"
                      className="form-control"
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="Create a test password"
                      required
                    />
                  </div>

                  <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '0.5rem' }}>
                    Create Account & Get User ID
                  </button>
                </form>
              )}
            </div>
          </div>
        ) : (
          /* Logged In View */
          <div>
            {/* Stats Summary Bar */}
            <div className="stats-banner">
              <div className="stat-item">
                <div className="stat-num">{currentUser.friendCount || currentUser.friends?.length || 0}</div>
                <div className="stat-label">Friends Connected</div>
              </div>
              <div className="stat-item">
                <div className="stat-num">{friendRecs.length}</div>
                <div className="stat-label">Friend Recommendations</div>
              </div>
              <div className="stat-item">
                <div className="stat-num">{oppRecs.length}</div>
                <div className="stat-label">Matching Opportunities</div>
              </div>
              <div className="stat-item">
                <div className="stat-num">{currentUser.takenOpportunities?.length || 0}</div>
                <div className="stat-label">Opportunities Taken</div>
              </div>
            </div>

            {/* Navigation Tabs */}
            <div className="tabs">
              <button
                className={`tab-btn ${activeTab === 'dashboard' ? 'active' : ''}`}
                onClick={() => setActiveTab('dashboard')}
              >
                👤 My Profile & Friends
              </button>
              <button
                className={`tab-btn ${activeTab === 'friend-recs' ? 'active' : ''}`}
                onClick={() => setActiveTab('friend-recs')}
              >
                🤝 Friend Recommendations ({friendRecs.length})
              </button>
              <button
                className={`tab-btn ${activeTab === 'opp-recs' ? 'active' : ''}`}
                onClick={() => setActiveTab('opp-recs')}
              >
                🎯 Opportunity Recommendations ({oppRecs.length})
              </button>
              <button
                className={`tab-btn ${activeTab === 'network' ? 'active' : ''}`}
                onClick={() => setActiveTab('network')}
              >
                🌐 Network & Graph Analytics
              </button>
              <button
                className={`tab-btn ${activeTab === 'all-opps' ? 'active' : ''}`}
                onClick={() => setActiveTab('all-opps')}
              >
                📂 Opportunity Directory & Tree
              </button>
            </div>

            {/* TAB 1: DASHBOARD */}
            {activeTab === 'dashboard' && (
              <div className="grid grid-cols-2">
                {/* Profile Card */}
                <div className="card">
                  <div className="card-header">
                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                      <div className="user-avatar">{currentUser.name.charAt(0)}</div>
                      <div>
                        <h2 className="card-title">{currentUser.name}</h2>
                        <span style={{ fontSize: '0.85rem', color: '#93c5fd' }}>
                          ID: {currentUser.id} • {currentUser.course}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div style={{ marginTop: '1rem' }}>
                    <h4 style={{ fontSize: '0.85rem', color: '#94a3b8', marginBottom: '0.35rem' }}>MY SKILLS</h4>
                    <div className="badge-group">
                      {currentUser.skills && currentUser.skills.length > 0 ? (
                        currentUser.skills.map((s) => (
                          <span key={s} className="tag tag-skill">{s}</span>
                        ))
                      ) : (
                        <span style={{ color: '#64748b' }}>No skills listed</span>
                      )}
                    </div>
                  </div>

                  <div style={{ marginTop: '1rem' }}>
                    <h4 style={{ fontSize: '0.85rem', color: '#94a3b8', marginBottom: '0.35rem' }}>MY INTERESTS</h4>
                    <div className="badge-group">
                      {currentUser.interests && currentUser.interests.length > 0 ? (
                        currentUser.interests.map((i) => (
                          <span key={i} className="tag tag-interest">{i}</span>
                        ))
                      ) : (
                        <span style={{ color: '#64748b' }}>No interests listed</span>
                      )}
                    </div>
                  </div>

                  {/* Opportunities Received */}
                  <div style={{ marginTop: '1.25rem' }}>
                    <h4 style={{ fontSize: '0.85rem', color: '#94a3b8', marginBottom: '0.5rem' }}>
                      COMPLETED / RECEIVED OPPORTUNITIES (:TOOK)
                    </h4>
                    {currentUser.takenOpportunities && currentUser.takenOpportunities.length > 0 ? (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                        {currentUser.takenOpportunities.map((o) => (
                          <div
                            key={o.id}
                            style={{
                              padding: '0.5rem 0.75rem',
                              background: '#0a1329',
                              border: '1px solid var(--border)',
                              borderRadius: '6px',
                              display: 'flex',
                              justifyContent: 'space-between',
                              alignItems: 'center',
                            }}
                          >
                            <span style={{ fontWeight: 600, fontSize: '0.85rem' }}>{o.name}</span>
                            <span className={`tag tag-type ${o.type.toLowerCase()}`}>{o.type}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <span style={{ color: '#64748b', fontSize: '0.85rem' }}>
                        No opportunities taken yet. Explore the Opportunity Recommendations tab!
                      </span>
                    )}
                  </div>
                </div>

                {/* Current Friends List */}
                <div className="card">
                  <div className="card-header">
                    <h3 className="card-title">My Friends ({currentUser.friends?.length || 0})</h3>
                    <span style={{ fontSize: '0.8rem', color: '#94a3b8' }}>Stored in Neo4j as (:FRIEND)</span>
                  </div>

                  {currentUser.friends && currentUser.friends.length > 0 ? (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', maxHeight: '420px', overflowY: 'auto' }}>
                      {currentUser.friends.map((f) => (
                        <div
                          key={f.id}
                          style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            padding: '0.6rem 0.85rem',
                            background: '#0a1329',
                            border: '1px solid var(--border)',
                            borderRadius: '8px',
                          }}
                        >
                          <div>
                            <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{f.name}</div>
                            <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
                              ID: {f.id} • {f.course}
                            </div>
                          </div>
                          <button
                            className="btn btn-outline btn-sm"
                            onClick={() => {
                              setCompareUser1(String(currentUser.id));
                              setCompareUser2(String(f.id));
                              setActiveTab('network');
                            }}
                          >
                            Mutual Friends
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div style={{ textAlign: 'center', padding: '2rem', color: '#64748b' }}>
                      <p>You have no friends connected yet.</p>
                      <button
                        className="btn btn-primary btn-sm"
                        style={{ marginTop: '0.75rem' }}
                        onClick={() => setActiveTab('friend-recs')}
                      >
                        Find Recommendations
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB 2: FRIEND RECOMMENDATIONS */}
            {activeTab === 'friend-recs' && (
              <div>
                <div style={{ marginBottom: '1rem', color: '#94a3b8', fontSize: '0.9rem' }}>
                  Ranked by graph BFS traversal, mutual connections (weight: 2), common skills (weight: 1), and shared interests (weight: 1).
                </div>

                {friendRecs.length > 0 ? (
                  <div className="grid grid-cols-2">
                    {friendRecs.map((rec, idx) => (
                      <div key={rec.user.id} className="card">
                        <div className="card-header">
                          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                            <div className="user-avatar" style={{ width: '40px', height: '40px', fontSize: '1rem' }}>
                              {rec.user.name.charAt(0)}
                            </div>
                            <div>
                              <div style={{ fontWeight: 700, fontSize: '1rem' }}>
                                #{idx + 1} {rec.user.name}
                              </div>
                              <div style={{ fontSize: '0.8rem', color: '#93c5fd' }}>
                                ID: {rec.user.id} • {rec.user.course}
                              </div>
                            </div>
                          </div>
                          <span style={{ fontSize: '0.8rem', fontWeight: 700, color: '#38bdf8' }}>
                            Score: {rec.score}
                          </span>
                        </div>

                        {/* Match Bar */}
                        <div className="match-bar-container">
                          <div className="match-header">
                            <span style={{ fontSize: '0.8rem', color: '#94a3b8' }}>Graph Match Compatibility</span>
                            <span style={{ color: rec.percentage > 70 ? '#10b981' : rec.percentage > 40 ? '#3b82f6' : '#f59e0b' }}>
                              {rec.percentage}%
                            </span>
                          </div>
                          <div className="progress-track">
                            <div
                              className={`progress-fill ${rec.percentage > 70 ? 'fill-high' : rec.percentage > 40 ? 'fill-med' : 'fill-low'}`}
                              style={{ width: `${Math.max(5, rec.percentage)}%` }}
                            />
                          </div>
                        </div>

                        {/* Recommendation Breakdown */}
                        <div style={{ fontSize: '0.8rem', marginTop: '0.5rem', display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                          {rec.mutualFriends?.length > 0 && (
                            <div>
                              <strong style={{ color: '#93c5fd' }}>Mutual Friends ({rec.mutualFriends.length}): </strong>
                              <span style={{ color: '#cbd5e1' }}>{rec.mutualFriends.map(m => m.name).join(', ')}</span>
                            </div>
                          )}
                          {rec.commonSkills?.length > 0 && (
                            <div>
                              <strong style={{ color: '#60a5fa' }}>Common Skills: </strong>
                              <span style={{ color: '#cbd5e1' }}>{rec.commonSkills.join(', ')}</span>
                            </div>
                          )}
                          {rec.commonInterests?.length > 0 && (
                            <div>
                              <strong style={{ color: '#c4b5fd' }}>Shared Interests: </strong>
                              <span style={{ color: '#cbd5e1' }}>{rec.commonInterests.join(', ')}</span>
                            </div>
                          )}
                        </div>

                        <button
                          className="btn btn-primary btn-sm"
                          style={{ width: '100%', marginTop: '1rem' }}
                          onClick={() => handleAddFriend(rec.user.id)}
                        >
                          ➕ Add Friend
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
                    <h3>No new friend recommendations at this time</h3>
                    <p style={{ color: '#94a3b8', marginTop: '0.5rem' }}>
                      Try adding new skills or interests to your profile to discover more matching students!
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: OPPORTUNITY RECOMMENDATIONS */}
            {activeTab === 'opp-recs' && (
              <div>
                <div style={{ marginBottom: '1rem', color: '#94a3b8', fontSize: '0.9rem' }}>
                  Opportunities are matched when you possess the required skill (+2 points), with extra priority given to shared interest areas (+2 points bonus).
                </div>

                {oppRecs.length > 0 ? (
                  <div className="grid grid-cols-2">
                    {oppRecs.map((rec, idx) => (
                      <div key={rec.opportunity.id} className="card">
                        <div className="card-header">
                          <div>
                            <div style={{ fontWeight: 700, fontSize: '1.05rem', color: '#fff' }}>
                              #{idx + 1} {rec.opportunity.name}
                            </div>
                            <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.35rem' }}>
                              <span className={`tag tag-type ${rec.opportunity.type.toLowerCase()}`}>
                                {rec.opportunity.type}
                              </span>
                              <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>ID: {rec.opportunity.id}</span>
                            </div>
                          </div>
                          <span style={{ fontSize: '1.1rem', fontWeight: 800, color: rec.percentage === 100 ? '#10b981' : '#38bdf8' }}>
                            {rec.percentage}%
                          </span>
                        </div>

                        <div className="match-bar-container">
                          <div className="progress-track">
                            <div
                              className={`progress-fill ${rec.percentage === 100 ? 'fill-high' : 'fill-med'}`}
                              style={{ width: `${rec.percentage}%` }}
                            />
                          </div>
                        </div>

                        <div style={{ fontSize: '0.85rem', marginTop: '0.5rem', display: 'flex', flexDirection: 'column', gap: '0.3rem' }}>
                          <div>
                            <span style={{ color: '#94a3b8' }}>Required Skill: </span>
                            <span className="tag tag-skill">{rec.opportunity.skill}</span>
                            <span style={{ color: '#10b981', marginLeft: '0.35rem', fontWeight: 'bold' }}>✓ Matched</span>
                          </div>
                          <div>
                            <span style={{ color: '#94a3b8' }}>Interest Area: </span>
                            <span className="tag tag-interest">{rec.opportunity.interest}</span>
                            {rec.interestMatched ? (
                              <span style={{ color: '#10b981', marginLeft: '0.35rem', fontWeight: 'bold' }}>✓ Bonus Match</span>
                            ) : (
                              <span style={{ color: '#64748b', marginLeft: '0.35rem' }}>(Exploratory)</span>
                            )}
                          </div>
                        </div>

                        <button
                          className="btn btn-success btn-sm"
                          style={{ width: '100%', marginTop: '1rem' }}
                          onClick={() => handleTakeOpportunity(rec.opportunity.id)}
                        >
                          🎯 Apply / Receive Opportunity
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
                    <h3>No matching opportunities found</h3>
                    <p style={{ color: '#94a3b8', marginTop: '0.5rem' }}>
                      Opportunities are matched against your profile skills. You have already received or none match your current skills.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* TAB 4: NETWORK & GRAPH ANALYTICS */}
            {activeTab === 'network' && (
              <div className="grid grid-cols-2">
                {/* Mutual & Common Comparator */}
                <div className="card">
                  <h3 className="card-title" style={{ marginBottom: '0.5rem' }}>
                    🔍 Compare Any 2 Users (Mutual & Common Graph)
                  </h3>
                  <p style={{ fontSize: '0.8rem', color: '#94a3b8', marginBottom: '1rem' }}>
                    Find mutual friends, common skills, and shared interests between two users.
                  </p>

                  <form onSubmit={handleCompareUsers}>
                    <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1rem' }}>
                      <div style={{ flex: 1 }}>
                        <label className="form-label">First User ID</label>
                        <input
                          type="number"
                          className="form-control"
                          value={compareUser1}
                          onChange={(e) => setCompareUser1(e.target.value)}
                          placeholder="e.g. 1"
                          required
                        />
                      </div>
                      <div style={{ flex: 1 }}>
                        <label className="form-label">Second User ID</label>
                        <input
                          type="number"
                          className="form-control"
                          value={compareUser2}
                          onChange={(e) => setCompareUser2(e.target.value)}
                          placeholder="e.g. 7"
                          required
                        />
                      </div>
                    </div>

                    <button type="submit" className="btn btn-primary btn-sm" style={{ width: '100%' }}>
                      Analyze Relationship
                    </button>
                  </form>

                  {mutualResult && (
                    <div style={{ marginTop: '1.25rem', borderTop: '1px solid var(--border)', paddingTop: '1rem' }}>
                      <h4 style={{ fontSize: '0.85rem', color: '#93c5fd', marginBottom: '0.35rem' }}>
                        MUTUAL FRIENDS ({mutualResult.length})
                      </h4>
                      {mutualResult.length > 0 ? (
                        <ul style={{ paddingLeft: '1.2rem', fontSize: '0.85rem' }}>
                          {mutualResult.map(m => (
                            <li key={m.id}>{m.name} ({m.course})</li>
                          ))}
                        </ul>
                      ) : (
                        <p style={{ fontSize: '0.85rem', color: '#64748b' }}>No mutual friends found.</p>
                      )}
                    </div>
                  )}

                  {commonAttrs && (
                    <div style={{ marginTop: '1rem' }}>
                      <h4 style={{ fontSize: '0.85rem', color: '#60a5fa', marginBottom: '0.35rem' }}>
                        COMMON SKILLS ({commonAttrs.commonSkills.length})
                      </h4>
                      <div className="badge-group">
                        {commonAttrs.commonSkills.length > 0 ? (
                          commonAttrs.commonSkills.map(s => <span key={s} className="tag tag-skill">{s}</span>)
                        ) : (
                          <span style={{ fontSize: '0.85rem', color: '#64748b' }}>None</span>
                        )}
                      </div>

                      <h4 style={{ fontSize: '0.85rem', color: '#c4b5fd', marginTop: '0.75rem', marginBottom: '0.35rem' }}>
                        SHARED INTERESTS ({commonAttrs.commonInterests.length})
                      </h4>
                      <div className="badge-group">
                        {commonAttrs.commonInterests.length > 0 ? (
                          commonAttrs.commonInterests.map(i => <span key={i} className="tag tag-interest">{i}</span>)
                        ) : (
                          <span style={{ fontSize: '0.85rem', color: '#64748b' }}>None</span>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* DFS Network Traversal */}
                <div className="card">
                  <h3 className="card-title" style={{ marginBottom: '0.5rem' }}>
                    🕸️ DFS Network Traversal
                  </h3>
                  <p style={{ fontSize: '0.8rem', color: '#94a3b8', marginBottom: '1rem' }}>
                    Demonstrates Depth-First Search traversal through the friendship graph starting from your account:
                  </p>

                  <div style={{ maxHeight: '350px', overflowY: 'auto' }}>
                    {dfsTraversal.length > 0 ? (
                      <ol style={{ paddingLeft: '1.25rem', fontSize: '0.85rem', display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                        {dfsTraversal.map((node, i) => (
                          <li key={node.id} style={{ color: i === 0 ? '#38bdf8' : '#cbd5e1' }}>
                            <strong>{node.name}</strong> (ID: {node.id}) — {node.course}
                            {i === 0 && <span style={{ color: '#10b981', marginLeft: '0.5rem' }}>(Root / Start)</span>}
                          </li>
                        ))}
                      </ol>
                    ) : (
                      <p style={{ color: '#64748b' }}>No connections in network traversal.</p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 5: OPPORTUNITY DIRECTORY & TREE */}
            {activeTab === 'all-opps' && (
              <div className="grid grid-cols-2">
                {/* Hierarchical Tree View */}
                <div className="card">
                  <h3 className="card-title" style={{ marginBottom: '0.5rem' }}>
                    🌳 Hierarchical Opportunity Tree
                  </h3>
                  <p style={{ fontSize: '0.8rem', color: '#94a3b8', marginBottom: '1rem' }}>
                    Category hierarchy tree stored as structured nodes:
                  </p>

                  {opportunityTree ? (
                    <div>
                      <div style={{ fontWeight: 800, color: '#38bdf8', fontSize: '1rem' }}>
                        📁 {opportunityTree.category}
                      </div>
                      {opportunityTree.children.map((branch) => (
                        <div key={branch.category} className="tree-branch">
                          <div className="tree-node-title">
                            📂 {branch.category} ({branch.items.length} items)
                          </div>
                          <div style={{ marginTop: '0.35rem', display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                            {branch.items.slice(0, 10).map((item) => (
                              <div key={item.id} style={{ fontSize: '0.8rem', color: '#cbd5e1' }}>
                                • <strong>{item.name}</strong> (Skill: {item.skill}, Interest: {item.interest})
                              </div>
                            ))}
                            {branch.items.length > 10 && (
                              <div style={{ fontSize: '0.75rem', color: '#64748b' }}>
                                + {branch.items.length - 10} more {branch.category} opportunities
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p style={{ color: '#64748b' }}>Loading tree...</p>
                  )}
                </div>

                {/* Add New Opportunity Form */}
                <div className="card">
                  <h3 className="card-title" style={{ marginBottom: '0.5rem' }}>
                    ➕ Add New Opportunity
                  </h3>
                  <p style={{ fontSize: '0.8rem', color: '#94a3b8', marginBottom: '1rem' }}>
                    Publish a new opportunity into the system and database:
                  </p>

                  <form onSubmit={handleCreateOpportunity}>
                    <div className="form-group">
                      <label className="form-label">Opportunity Title</label>
                      <input
                        type="text"
                        className="form-control"
                        value={newOppName}
                        onChange={(e) => setNewOppName(e.target.value)}
                        placeholder="e.g. AI-Powered Chatbot Workshop"
                        required
                      />
                    </div>

                    <div className="form-group">
                      <label className="form-label">Category / Type</label>
                      <select
                        className="form-control"
                        value={newOppType}
                        onChange={(e) => setNewOppType(e.target.value)}
                      >
                        <option value="Project">Project</option>
                        <option value="Workshop">Workshop</option>
                        <option value="Course">Course</option>
                      </select>
                    </div>

                    <div className="form-group">
                      <label className="form-label">Required Skill</label>
                      <select
                        className="form-control"
                        value={newOppSkill}
                        onChange={(e) => setNewOppSkill(e.target.value)}
                      >
                        {catalogs.skills.map(s => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>

                    <div className="form-group">
                      <label className="form-label">Interest Area</label>
                      <select
                        className="form-control"
                        value={newOppInterest}
                        onChange={(e) => setNewOppInterest(e.target.value)}
                      >
                        {catalogs.interests.map(i => (
                          <option key={i} value={i}>{i}</option>
                        ))}
                      </select>
                    </div>

                    <button type="submit" className="btn btn-primary btn-sm" style={{ width: '100%' }}>
                      Save Opportunity to Database
                    </button>
                  </form>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
