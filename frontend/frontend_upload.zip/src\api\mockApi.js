// Mock API provider for instant UI preview and demonstration

const mockUsers = [
  {
    id: 1,
    name: "Kavya Rana",
    course: "B.Tech CSE",
    skills: ["Data_Structures", "Operating_Systems", "Problem_Solving", "Communication"],
    interests: ["Hackathons", "Research"],
    password: "ehn#$QJ2ay",
    friends: [
      { id: 7, name: "Juhi Mishra", course: "B.Sc Computer Science" },
      { id: 17, name: "Rohan Joshi", course: "B.Tech IT" },
      { id: 23, name: "Ankit Panwar", course: "B.Tech CSE" },
      { id: 83, name: "Ira Sharma", course: "B.Tech CSE" },
    ],
    takenOpportunities: [
      { id: 70, name: "Data Structures and Algorithms in C++", type: "Course", skill: "Data_Structures", interest: "Hackathons" }
    ],
  },
  {
    id: 2,
    name: "Bhavya Bhandari",
    course: "B.Tech CSE AI ML",
    skills: ["Deep_Learning", "Kubernetes", "Critical_Thinking"],
    interests: ["Artificial_Intelligence", "Research", "Robotics"],
    password: "oKY!HDME72",
    friends: [
      { id: 5, name: "Varun Chauhan", course: "B.Sc Data Science" },
      { id: 12, name: "Aditya Joshi", course: "B.Sc Data Science" },
    ],
    takenOpportunities: [],
  },
  {
    id: 38,
    name: "Chirag Verma",
    course: "B.Sc Computer Science",
    skills: ["C", "Operating_Systems", "C++", "Teamwork"],
    interests: ["Gaming", "Research"],
    password: "password",
    friends: [
      { id: 17, name: "Rohan Joshi", course: "B.Tech IT" },
      { id: 23, name: "Ankit Panwar", course: "B.Tech CSE" },
    ],
    takenOpportunities: [],
  },
];

const mockOpportunities = [
  { id: 1, name: "Python Programming Bootcamp", type: "Course", skill: "Python", interest: "Artificial_Intelligence" },
  { id: 2, name: "Python Automation Mini Project", type: "Project", skill: "Python", interest: "Research" },
  { id: 70, name: "Data Structures and Algorithms in C++", type: "Course", skill: "Data_Structures", interest: "Hackathons" },
  { id: 71, name: "Library Management System Project", type: "Project", skill: "Data_Structures", interest: "Gaming" },
  { id: 74, name: "Operating Systems Concepts", type: "Course", skill: "Operating_Systems", interest: "Hackathons" },
  { id: 75, name: "DBMS Concepts Workshop", type: "Workshop", skill: "DBMS", interest: "Research" },
];

export const mockApi = {
  getHealth: async () => ({
    status: 'ok',
    neo4jConnected: false,
    mode: 'Mock Preview Mode (Demo)',
    stats: {
      totalUsers: 100,
      totalOpportunities: 75,
      totalFriendships: 212,
      totalTakenOpportunities: 20,
    },
  }),

  getCatalogs: async () => ({
    skills: ["Data_Structures", "Operating_Systems", "Problem_Solving", "Communication", "Python", "Deep_Learning", "C++"],
    interests: ["Hackathons", "Research", "Artificial_Intelligence", "Gaming", "Startups"],
    courses: ["B.Tech CSE", "B.Tech CSE AI ML", "B.Sc Computer Science", "MCA", "B.Tech IT"],
  }),

  login: async (userId, password) => {
    const user = mockUsers.find((u) => u.id === Number(userId));
    if (!user) throw new Error("User not found in mock store.");
    return { message: "Mock login successful!", user };
  },

  register: async (data) => {
    const newUser = {
      id: mockUsers.length + 1,
      ...data,
      friends: [],
      takenOpportunities: [],
    };
    mockUsers.push(newUser);
    return { message: "Account created!", user: newUser };
  },

  getAllUsers: async () => mockUsers,
  getUser: async (id) => {
    const u = mockUsers.find((x) => x.id === Number(id));
    if (!u) throw new Error("User not found");
    return u;
  },

  getFriendRecommendations: async () => [
    {
      user: {
        id: 38,
        name: "Chirag Verma",
        course: "B.Sc Computer Science",
        skills: ["C", "Operating_Systems", "C++", "Teamwork"],
        interests: ["Gaming", "Research"],
      },
      score: 6,
      percentage: 67,
      mutualFriends: [{ id: 17, name: "Rohan Joshi" }, { id: 23, name: "Ankit Panwar" }],
      commonSkills: ["Operating_Systems"],
      commonInterests: ["Research"],
    },
    {
      user: {
        id: 2,
        name: "Bhavya Bhandari",
        course: "B.Tech CSE AI ML",
        skills: ["Deep_Learning", "Kubernetes", "Critical_Thinking"],
        interests: ["Artificial_Intelligence", "Research"],
      },
      score: 3,
      percentage: 33,
      mutualFriends: [],
      commonSkills: [],
      commonInterests: ["Research"],
    },
  ],

  getOpportunityRecommendations: async () => [
    {
      opportunity: { id: 74, name: "Operating Systems Concepts", type: "Course", skill: "Operating_Systems", interest: "Hackathons" },
      score: 4,
      percentage: 100,
      skillMatched: true,
      interestMatched: true,
    },
    {
      opportunity: { id: 71, name: "Library Management System Project", type: "Project", skill: "Data_Structures", interest: "Gaming" },
      score: 2,
      percentage: 50,
      skillMatched: true,
      interestMatched: false,
    },
  ],

  addFriendship: async () => ({ success: true, message: "Friend added (mock)!" }),
  getMutualFriends: async () => [{ id: 17, name: "Rohan Joshi", course: "B.Tech IT" }],
  getCommonAttributes: async () => ({
    commonSkills: ["Operating_Systems"],
    commonInterests: ["Research"],
  }),
  getDfsTraversal: async () => [
    { id: 1, name: "Kavya Rana", course: "B.Tech CSE" },
    { id: 7, name: "Juhi Mishra", course: "B.Sc Computer Science" },
    { id: 17, name: "Rohan Joshi", course: "B.Tech IT" },
  ],

  getOpportunities: async (tree = false) => {
    if (tree) {
      return {
        category: "Opportunities",
        children: [
          { category: "Project", items: mockOpportunities.filter(o => o.type === 'Project') },
          { category: "Workshop", items: mockOpportunities.filter(o => o.type === 'Workshop') },
          { category: "Course", items: mockOpportunities.filter(o => o.type === 'Course') },
        ],
      };
    }
    return mockOpportunities;
  },

  takeOpportunity: async () => ({ success: true, message: "Opportunity added to your profile (mock)!" }),
  createOpportunity: async (data) => ({ id: 99, ...data }),
};
