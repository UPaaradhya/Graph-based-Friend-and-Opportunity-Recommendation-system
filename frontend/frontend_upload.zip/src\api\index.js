import { apiClient } from './client.js';
import { mockApi } from './mockApi.js';

const mode = import.meta.env.VITE_DATA_MODE || 'api';

export const isMockMode = mode === 'mock';

// Export the active API based on environment configuration
export const api = isMockMode ? mockApi : apiClient;

export default api;
