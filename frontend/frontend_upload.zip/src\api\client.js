// Real API client calling the backend REST endpoints

const API_BASE = '/api';

async function request(endpoint, options = {}) {
  const url = `${API_BASE}${endpoint}`;
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  const response = await fetch(url, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || data.message || `Request failed with status ${response.status}`);
  }
  return data;
}

export const apiClient = {
  // System Health & Stats
  getHealth: () => request('/health'),

  // Catalogs
  getCatalogs: () => request('/catalogs'),

  // Authentication
  login: (userId, password) =>
    request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ userId, password }),
    }),

  register: (userData) =>
    request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    }),

  // Users
  getAllUsers: () => request('/users'),
  getUser: (id) => request(`/users/${id}`),

  // Recommendations
  getFriendRecommendations: (userId, limit = 10) =>
    request(`/users/${userId}/recommendations/friends?limit=${limit}`),

  getOpportunityRecommendations: (userId, limit = 10) =>
    request(`/users/${userId}/recommendations/opportunities?limit=${limit}`),

  // Friendships & Graph
  addFriendship: (user1, user2) =>
    request('/friendships', {
      method: 'POST',
      body: JSON.stringify({ user1, user2 }),
    }),

  getMutualFriends: (user1, user2) =>
    request(`/friendships/mutual?user1=${user1}&user2=${user2}`),

  getCommonAttributes: (user1, user2) =>
    request(`/friendships/common?user1=${user1}&user2=${user2}`),

  getDfsTraversal: (userId) => request(`/graph/dfs/${userId}`),

  // Opportunities
  getOpportunities: (tree = false) =>
    request(`/opportunities${tree ? '?tree=true' : ''}`),

  takeOpportunity: (userId, oppId) =>
    request(`/users/${userId}/opportunities/${oppId}/take`, {
      method: 'POST',
    }),

  createOpportunity: (data) =>
    request('/opportunities', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
};
